# -*- coding: utf-8 -*-
"""
Created on Wed Jun 23 06:52:18 2021

@author: 
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import ndimage as ndi
from skimage.util import random_noise
from skimage import feature
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
from skimage.feature import peak_local_max
from skimage import data, img_as_float

import cv2
from skimage.feature import canny

# Generate noisy image of a square
# image = np.zeros((128, 128), dtype=float)
# image[32:-32, 32:-32] = 1

from PIL import Image
path='image1.jpg'
img = Image.open('image1.jpg')
gray = img.convert('L')   # 'L' stands for 'luminosity'
gray = np.asarray(gray)
image=gray

from skimage import data
from skimage import filters


#################Dilation - maximum_filter#######################
# image_max is the dilation of im with a 20*20 structuring element
# It is used within peak_local_max function
image_max = ndi.maximum_filter(image, size=1, mode='constant')
# Compute the Canny filter for two values of sigma
image_lcp_net = feature.canny(image_max)


# Compute the Canny filter for two values of sigma
edges_U_Net = feature.canny(image)


# display results
fig, ax = plt.subplots(nrows=1, ncols=4, figsize=(8, 4))

ax[0].imshow(gray, cmap='gray')
ax[0].set_title('test image', fontsize=15)

ax[1].imshow(edges_U_Net, cmap='gray')
ax[1].set_title('truth', fontsize=15)

ax[2].imshow(edges_U_Net, cmap='gray')
ax[2].set_title(r'U-Net', fontsize=15)

ax[3].imshow(image_lcp_net, cmap='gray')
ax[3].set_title(r'LCP-Net', fontsize=15)

for a in ax:
    a.axis('off')

fig.tight_layout()
plt.show()