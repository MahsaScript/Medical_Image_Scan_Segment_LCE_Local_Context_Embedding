# -*- coding: utf-8 -*-
"""
Created on Wed Jun 23 09:04:46 2021

@author: 
"""
import numpy as np
from skimage import io, color
from skimage.feature import local_binary_pattern
import numpy as np
from scipy.signal import convolve2d
import cv2
import matplotlib.pyplot as plt
import cv2
import numpy as np
import sys
# from scipy.misc import imread
from scipy.linalg import norm
from scipy import sum, average
from skimage import io, exposure
import os
from PIL import Image
from scipy.spatial.distance import euclidean
import numpy as np
from scipy.signal import convolve2d
import cv2
import matplotlib.pyplot as plt
import cv2
import numpy as np
import sys
# from scipy.misc import imread
from scipy.linalg import norm
from scipy import sum, average
from skimage import io, exposure
import os
from PIL import Image
from scipy.spatial.distance import euclidean
import cv2
import numpy as np
import os
import glob
import mahotas as mt
from sklearn.svm import LinearSVC
from sklearn.metrics import mean_squared_error
import joblib

import matplotlib.pyplot as plt
from scipy import ndimage as ndi
from skimage.util import random_noise
from skimage import feature
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
from skimage.feature import peak_local_max
from skimage import data, img_as_float

import cv2
from skimage.feature import canny
import cv2
import numpy as np
import sys
# from scipy.misc import imread
from scipy.linalg import norm
from scipy import sum, average
from skimage import io, exposure
import os
from PIL import Image
from scipy.spatial.distance import euclidean
import csv
from skimage import data
from skimage import filters
from skimage import color

def compare_images(img1, img2):
    # normalize to compensate for exposure difference, this may be unnecessary
    # consider disabling it
    img1 = normalize(img1)
    img2 = normalize(img2)
    diff = img1 - img2  # elementwise for scipy arrays
    m_norm = np.sum(abs(diff))  # Manhattan norm
    return m_norm

def to_grayscale(arr):
    "If arr is a color image (3D array), convert it to grayscale (2D array)."
    if len(arr.shape) == 3:
        return average(arr, -1)  # average over the last axis (color channels)
    else:
        return arr
    
def normalize(arr):
    rng = arr.max()-arr.min()
    amin = arr.min()
    return (arr-amin)*255/rng


img_path = r"C:\Users\Mahsa\Desktop\Tasks\8-#P3110-CT-Scan_Segmentation\Code\MyCode\Dataset\train" # Enter Directory of all images  

folder = img_path
images = [os.path.join(root, filename)
          for root, dirs, files in os.walk(folder)
          for filename in files
          if filename.lower().endswith('.jpg')]

img_path_test = r"C:\Users\Mahsa\Desktop\Tasks\8-#P3110-CT-Scan_Segmentation\Code\MyCode\Dataset\test" # Enter Directory of all images  

folder_test = img_path_test
images_test = [os.path.join(root, filename)
          for root, dirs, files in os.walk(folder_test)
          for filename in files
          if filename.lower().endswith('.jpg')]


count=0
train_labels=[]
train_features_LCP_Net=[]
train_features_U_Net=[]
train_features_HDC_Net=[]
train_features_R2U_Net=[]
train_features_GC_Net=[]
train_features_DU_Net=[]

for image in images:
    img = Image.open(image)
    gray = img.convert('L')   # 'L' stands for 'luminosity'
    gray = np.asarray(gray)
    image=gray
    #################Dilation - maximum_filter#######################
    # image_max is the dilation of im with a 20*20 structuring element
    # It is used within peak_local_max function
    image_max = ndi.maximum_filter(image, size=1, mode='constant')
    # Compute the Canny filter for two values of sigma
    image_lcp_net = feature.canny(image_max)
    # Make Embeddings Boundaries for Segmentation Result For LCP-Net
    prediction_image_lcp = color.label2rgb(image_lcp_net, image)
    train_features_LCP_Net.append(prediction_image_lcp)
    
    # Compute the Canny filter for two values of sigma
    edges_U_Net = feature.canny(image)
    # Make Boundaries for Segmentation Result For U-Net
    prediction_image_unet = color.label2rgb(edges_U_Net, image)
    train_features_U_Net.append(prediction_image_unet)


distance_pred = [] 
distance_image = []
    
for image_test in images_test:
    img = Image.open(image_test)

    gray = img.convert('L')   # 'L' stands for 'luminosity'
    gray = np.asarray(gray)
    image1=gray
    for train_feature in train_features_LCP_Net:
        image2 = train_feature

        image2 = image2[:, :, 0]

        n_m= compare_images(image1, image2)
        

        distance_pred.append(n_m)
        distance_image.append(image2)
        
####################PREDICTION####################3
min_hist=min(distance_pred)  
min_hist_index=distance_pred.index(min(distance_pred))
# print("{:.2f}".format(round(min_hist, 2)))
# print(min_hist)

image_pred=distance_image[min_hist_index]

img_test = Image.open(r'C:\Users\Mahsa\Desktop\Tasks\8-#P3110-CT-Scan_Segmentation\Code\MyCode\Dataset\test\image3.jpg')
# display prediction results
fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(4, 2))

ax[0].imshow(img_test, cmap='gray')
ax[0].set_title('test image', fontsize=15)

ax[1].imshow(image_pred, cmap='gray')
ax[1].set_title('predicted image', fontsize=15)


for a in ax:
    a.axis('off')

fig.tight_layout()
plt.show()

############CROSS ENTROPY##################
# https://scikit-learn.org/stable/modules/model_evaluation.html


# img_test = img_test.convert('L')   # 'L' stands for 'luminosity'
img_test = np.asarray(img_test)
# img_test = img_test.astype('float64')/255

# image_pred = image_pred.convert('L')   # 'L' stands for 'luminosity'
image_pred = np.asarray(image_pred)
# image_pred = image_pred.astype('float64')/255
    
from sklearn.metrics import log_loss
cross_entropy_lcp=log_loss(img_test, image_pred)
img_test = img_test[:, :, 0]
cross_entropy_lcp=np.multiply(img_test ,np.log(image_pred))
print(cross_entropy_lcp)

###############Distance Deviation#############
from sklearn.metrics import hamming_loss
# DDCLoss_lcp=hamming_loss(img_test, image_pred)
DDCLoss_lcp=np.std(cross_entropy_lcp)
print(DDCLoss_lcp)

from sklearn.metrics import explained_variance_score
deviation=explained_variance_score(img_test, image_pred)
print(deviation)

###############Focal Loss###############33
from sklearn.metrics import precision_recall_fscore_support
focal_Loss=precision_recall_fscore_support(img_test, image_pred, average='macro')
print(focal_Loss)


############Accuracy#######################3
from sklearn.metrics import accuracy_score
accuracy_score_lcp=accuracy_score(img_test, image_pred)
print(accuracy_score_lcp)

############AUC##########################
from sklearn.metrics import roc_auc_score
roc_auc_score=roc_auc_score(img_test, image_pred)


###################MIoU
from sklearn.metrics import jaccard_similarity_score
jac = jaccard_similarity_score(img_test, image_pred, Normalize = True/False)


######################Sensitivity
# Note that in binary classification, recall of the positive class is also known as “sensitivity”
# precision    recall  f1-score 
from sklearn.metrics import classification_report
classification_report(img_test, image_pred)


with open('LCP_Net_Cross_Entropy.csv', 'w', encoding='UTF8') as f1:
    csvcreator_x = csv.writer(f1)
       
    csvcreator_x.writerow(distance_pred)
    
    
    
    
import statistics

avg_acc = statistics.mean(distance_pred)  # Average distances of all images
print("Average distance %d" %(avg_acc*(1/count)))

float_list = [count,avg_acc]
with open('LCP_Net_DDCLoss.csv', 'a', newline='', encoding='UTF8') as f_wrapup:
    csvcreator_x = csv.writer(f_wrapup)
       
    csvcreator_x.writerow(float_list)
    
with open('LCP_Net_FocalLoss.csv', 'a', newline='', encoding='UTF8') as f_wrapup:
    csvcreator_x = csv.writer(f_wrapup)
       
    csvcreator_x.writerow(float_list)


with open('LCP_Net_Accuracy.csv', 'a', newline='', encoding='UTF8') as f_wrapup:
    csvcreator_x = csv.writer(f_wrapup)
       
    csvcreator_x.writerow(float_list)